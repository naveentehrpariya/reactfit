export default function AlreadyBooking(){
    return <>
       AlreadyBooking.js
    </>
}