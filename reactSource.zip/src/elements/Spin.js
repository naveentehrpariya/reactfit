export default function Spin() {
    return <>
        <div className="loader loader-bottom">
            <div className="dots">
                <span className="dot"></span>
                <span className="dot"></span>
                <span className="dot"></span>
            </div>
        </div>
    </>
}
